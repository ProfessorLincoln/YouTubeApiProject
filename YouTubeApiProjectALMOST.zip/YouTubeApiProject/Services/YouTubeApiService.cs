﻿using Google.Apis.Services;
using Google.Apis.YouTube.v3;
using YouTubeApiProject.Models;

namespace YouTubeApiProject.Services
{
    public class YouTubeApiService
    {
        private readonly string _apiKey;
        private List<YouTubeVideoModel> _cachedVideos = new List<YouTubeVideoModel>(); // Store last search results

        public YouTubeApiService(IConfiguration configuration)
        {
            _apiKey = configuration["YouTubeApiKey"]; // Fetch API key from appsettings.json
        }

        public async Task<List<YouTubeVideoModel>> SearchVideosAsync(string query, string uploadDate = "", string videoDuration = "")
        {
            var youtubeService = new YouTubeService(new BaseClientService.Initializer()
            {
                ApiKey = _apiKey,
                ApplicationName = "YoutubeProject"
            });

            var searchRequest = youtubeService.Search.List("snippet");
            searchRequest.Q = query;
            searchRequest.MaxResults = 27;
            searchRequest.Type = "video"; // Ensure only videos are fetched

            // 📌 Apply Upload Date Filter (PublishedAfter)
            if (!string.IsNullOrEmpty(uploadDate))
            {
                DateTime now = DateTime.UtcNow;
                switch (uploadDate.ToLower())
                {
                    case "today":
                        searchRequest.PublishedAfter = now.AddDays(-1).ToString("yyyy-MM-ddTHH:mm:ssZ");
                        break;
                    case "week":
                        searchRequest.PublishedAfter = now.AddDays(-7).ToString("yyyy-MM-ddTHH:mm:ssZ");
                        break;
                    case "month":
                        searchRequest.PublishedAfter = now.AddMonths(-1).ToString("yyyy-MM-ddTHH:mm:ssZ");
                        break;
                    case "year":
                        searchRequest.PublishedAfter = now.AddYears(-1).ToString("yyyy-MM-ddTHH:mm:ssZ");
                        break;
                }
            }

            // 📌 Apply Video Duration Filter
            if (!string.IsNullOrEmpty(videoDuration))
            {
                switch (videoDuration.ToLower())
                {
                    case "short":
                        searchRequest.VideoDuration = SearchResource.ListRequest.VideoDurationEnum.Short__;
                        break;
                    case "medium":
                        searchRequest.VideoDuration = SearchResource.ListRequest.VideoDurationEnum.Medium;
                        break;
                    case "long":
                        searchRequest.VideoDuration = SearchResource.ListRequest.VideoDurationEnum.Long__;
                        break;
                }
            }

            var searchResponse = await searchRequest.ExecuteAsync();

            _cachedVideos = searchResponse.Items.Select(item => new YouTubeVideoModel
            {
                Title = item.Snippet.Title,
                Description = item.Snippet.Description,
                ThumbnailUrl = item.Snippet.Thumbnails.Medium.Url,
                VideoUrl = "https://www.youtube.com/watch?v=" + item.Id.VideoId,
                PublishedDate = item.Snippet.PublishedAt?.ToString("yyyy-MM-dd") // Format the date
            }).ToList();

            Console.WriteLine($"[DEBUG] Cached Videos Count: {_cachedVideos.Count}"); // ✅ Check if videos are stored
            return _cachedVideos;
        }

        public List<YouTubeVideoModel> GetCachedVideos()
        {
            return _cachedVideos; // Return last searched videos
        }
    }
}
