﻿namespace YouTubeApiProject.Models
{
    public class YoutubeSearchViewModel
    {
    }
}
